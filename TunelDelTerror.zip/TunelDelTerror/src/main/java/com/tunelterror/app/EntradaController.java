package com.tunelterror.app;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class EntradaController implements Initializable {

    @FXML
    private TextField nombreField;

    @FXML
    private TextField apellidosField;

    @FXML
    private ComboBox<String> cursoComboBox;

    @FXML
    private Label errorLabel;

    /**
     * Este método se llama automáticamente después de que el FXML ha sido cargado.
     * Es perfecto para inicializar cosas, como las opciones del ComboBox.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Añade las opciones de cursos al ComboBox
        cursoComboBox.setItems(FXCollections.observableArrayList(
                "DAM1", "DAM2", "DAW1", "DAW2", "SMR1", "SMR2"
        ));
        errorLabel.setText(""); // Limpia la etiqueta de error al inicio
    }

    /**
     * Maneja el evento de clic en el botón "Entrar".
     */
    @FXML
    void handleEntrar(ActionEvent event) throws IOException {
        // 1. Recoger los datos de los campos
        String nombre = nombreField.getText().trim();
        String apellidos = apellidosField.getText().trim();
        String curso = cursoComboBox.getValue();

        // 2. Validar los datos
        if (nombre.isEmpty() || apellidos.isEmpty() || curso == null) {
            errorLabel.setText("¡Rellena todos los campos, mortal!");
            return; // Detiene la ejecución si hay un error
        }

        // 3. Si la validación es correcta, creamos el objeto Usuario
        Usuario usuario = new Usuario(nombre, apellidos, curso);

        // 4. Cargamos la nueva pantalla (ruleta.fxml)
        FXMLLoader loader = new FXMLLoader(Objects.requireNonNull(getClass().getResource("ruleta.fxml")));
        Parent ruletaParent = loader.load();

        // 5. Obtenemos una referencia al controlador de la nueva pantalla
        RuletaController ruletaController = loader.getController();

        // 6. Le pasamos los datos del usuario al nuevo controlador
        ruletaController.initData(usuario);

        // 7. Cambiamos la escena
        Scene ruletaScene = new Scene(ruletaParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(ruletaScene);
        window.show();
    }
}
