package com.tunelterror.app;

/**
 * Un objeto simple (DTO - Data Transfer Object) para pasar los datos del usuario
 * entre controladores de forma ordenada.
 */
public class Usuario {
    private final String nombre;
    private final String apellidos;
    private final String curso;

    public Usuario(String nombre, String apellidos, String curso) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.curso = curso;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getCurso() {
        return curso;
    }

    public String getNombreCompleto() {
        return nombre + " " + apellidos;
    }
}
