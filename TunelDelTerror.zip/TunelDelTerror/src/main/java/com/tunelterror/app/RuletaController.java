package com.tunelterror.app;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import java.util.Random;

public class RuletaController {

    @FXML
    private Label infoUsuarioLabel;

    @FXML
    private Label resultadoLabel;

    @FXML
    private ImageView ruletaImage;

    @FXML
    private Button girarButton;

    private final Random random = new Random();

    // Listas de trucos y tratos para darle más personalidad
    private final String[] trucos = {
            "TRUCO: ¡Cuenta un chiste de terror!",
            "TRUCO: ¡Imita a un zombie!",
            "TRUCO: ¡Canta la canción de la Familia Addams!",
            "TRUCO: ¡Haz tu grito más terrorífico!"
    };

    private final String[] tratos = {
            "TRATO: ¡Te salvas... por ahora!",
            "TRATO: ¡Has ganado un caramelo virtual!",
            "TRATO: ¡Los espíritus te conceden un día de suerte!",
            "TRATO: ¡Puedes pedir un deseo a la calabaza!"
    };

    /**
     * Método para recibir los datos del usuario desde la pantalla de entrada.
     * @param usuario El objeto con la información del usuario.
     */
    public void initData(Usuario usuario) {
        infoUsuarioLabel.setText(usuario.getNombreCompleto() + " - " + usuario.getCurso());
        resultadoLabel.setText("");
    }

    /**
     * Maneja el evento de clic en el botón "Girar".
     */
    @FXML
    void handleGirar(ActionEvent event) {
        // Desactivamos el botón para evitar múltiples clics durante la animación
        girarButton.setDisable(true);
        resultadoLabel.setText("Girando...");

        // Calculamos un ángulo de giro aleatorio
        // 360 * 5 -> 5 vueltas completas
        // 1 + random.nextInt(360) -> más un ángulo final aleatorio
        float anguloFinal = 360 * 5 + random.nextInt(360) + 1;

        // Creamos la animación de rotación
        RotateTransition rt = new RotateTransition(Duration.seconds(3.5), ruletaImage);
        rt.setToAngle(ruletaImage.getRotate() + anguloFinal); // Gira desde su posición actual
        rt.setInterpolator(Interpolator.EASE_OUT); // Efecto de desaceleración suave

        // Esto se ejecuta cuando la animación termina
        rt.setOnFinished(e -> {
            // Decidimos el resultado
            boolean esTrato = random.nextBoolean(); // 50/50
            if (esTrato) {
                resultadoLabel.setText(tratos[random.nextInt(tratos.length)]);
                resultadoLabel.setStyle("-fx-text-fill: #39ff14;"); // Color verde neón
            } else {
                resultadoLabel.setText(trucos[random.nextInt(trucos.length)]);
                resultadoLabel.setStyle("-fx-text-fill: #ff5722;"); // Color naranja
            }

            // Reactivamos el botón
            girarButton.setDisable(false);
        });

        // ¡Iniciamos la animación!
        rt.play();
    }
}
