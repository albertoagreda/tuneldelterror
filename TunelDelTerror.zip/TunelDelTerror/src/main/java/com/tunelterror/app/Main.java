package com.tunelterror.app;

// Importaciones necesarias de JavaFX
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Clase principal que inicia la aplicación JavaFX.
 * Esta es la versión más básica y estándar posible.
 */
public class Main extends Application {

    /**
     * Este es el método que JavaFX llama para empezar todo.
     * @param primaryStage La ventana principal de la aplicación.
     */
    @Override
    public void start(Stage primaryStage) throws IOException {
        // 1. Carga la vista desde el archivo FXML.
        // Asegúrate de que "entrada.fxml" está en la carpeta 'resources/com/tunelterror/app'.
        Parent root = FXMLLoader.load(getClass().getResource("entrada.fxml"));

        // 2. Crea la escena que contendrá la vista.
        Scene scene = new Scene(root);

        // 3. Configura y muestra la ventana.
        primaryStage.setTitle("Túnel del Terror");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * El punto de entrada del programa.
     */
    public static void main(String[] args) {
        launch(args);
    }
}

